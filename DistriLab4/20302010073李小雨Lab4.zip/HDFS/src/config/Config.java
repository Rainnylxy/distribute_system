package config;

/**
 * @author little rain
 * @date 2023/3/18 13:05
 */
public interface Config {
   public static int BLOCKSIZE = 4*1024;
}
