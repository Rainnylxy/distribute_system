package impl;
//TODO: your implementation
import api.DataNodePOA;
import config.Config;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

public class DataNodeImpl extends DataNodePOA {
    int BLOCK_SIZE = Config.BLOCKSIZE;
    String dir = System.getProperty("user.dir");

    /*public DataNodeImpl(int id) {
        this.dir = this.dir+"/datanode_"+id+"/";
    }*/

    public DataNodeImpl(){}

    public DataNodeImpl(String port){
        if(port.equals("1051")){
            dir = dir + "/datanodeFiles/datanode1/";
        }else {
            dir = dir +"/datanodeFiles/datanode2/";
        }
    }

    @Override
    public byte[] read(int block_id) {
        try {
            FileInputStream fis = new FileInputStream(dir + String.valueOf(block_id)+".txt");
            byte[] bytes = new byte[BLOCK_SIZE];
            fis.read(bytes);
            fis.close();
            ArrayList<Byte> bytes1 = new ArrayList<>();
            for(int i=0;i<bytes.length;i++){
                if(bytes[i]!=0x00){
                    bytes1.add(bytes[i]);
                }
            }
            byte[] bytes2 = new byte[Config.BLOCKSIZE];
            for(int i=0;i<bytes1.size();i++){
                bytes2[i]=bytes1.get(i);
            }
            return bytes2;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return new byte[0];
    }

    /**
     * @param block_id ָ�����ڸ�DataNode���blockID����NameNode���䣬�������ļ�������blockid
     * @param bytes ��Ҫд�������
     */
    @Override
    public void append(int block_id, byte[] bytes){
        try {
            FileOutputStream fos = new FileOutputStream(dir+ String.valueOf(block_id)+".txt",true);
            ArrayList<Byte> bytes1 = new ArrayList<>();
            for(int i=0;i<bytes.length;i++){
                if(bytes[i]!=0x00){
                    bytes1.add(bytes[i]);
                }
            }
            byte[] bytes2 = new byte[bytes1.size()];
            for(int i=0;i<bytes1.size();i++){
                bytes2[i]=bytes1.get(i);
            }
            fos.write(bytes2);
            fos.close();
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    @Override
    public int randomBlockId() {
        return 0;
    }
}
