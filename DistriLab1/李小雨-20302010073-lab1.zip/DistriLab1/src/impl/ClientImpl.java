package impl;
//TODO: your implementation
import api.*;
import config.Config;
import lancher.ClientLancher;
import org.omg.CORBA.ORB;
import org.omg.CosNaming.*;
import org.omg.PortableServer.POA;
import org.omg.PortableServer.POAHelper;
import utils.FileDesc;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class ClientImpl implements Client{
    NameNode nameNode;
    DataNode dataNode;
    String filepath;
    FileMetaData fileMetaData;
    ArrayList<FileDesc> fileDescArrayList = new ArrayList<>();
    int fdId = 4*1024;

    public ClientImpl(NameNode nameNode) {
        this.nameNode = nameNode;
    }

    public ClientImpl() {
        try {
            String[] args = new String[6];
            args[0]="-port";
            args[2]="-ORBInitialPort";
            args[4]="-ORBInitialHost";
            args[1]="1049";
            args[3]="1050";
            args[5]="localhost";
            // ORB initial
            ORB orb = ORB.init(args, null);

            // Get the context
            org.omg.CORBA.Object obRef = orb
                    .resolve_initial_references("NameService");
            NamingContext ncRef = NamingContextHelper.narrow(obRef);

            NameComponent nc = new NameComponent("NameNodeLancher", "");
            NameComponent[] path = { nc };

            nameNode = NameNodeHelper.narrow(ncRef.resolve(path));
        } catch (Exception e) {
            System.out.println("Calling CORBA fails." + e);
        }
    }

    public void connectDataNode(String[] ports){
        try {
            String[] args = new String[6];
            args[0]="-port";
            args[2]="-ORBInitialPort";
            args[4]="-ORBInitialHost";
            args[1]=ports[0];
            args[3]=ports[1];
            args[5]=ports[2];
            // ORB initial
            ORB orb = ORB.init(args, null);

            // Get the context
            org.omg.CORBA.Object obRef = orb
                    .resolve_initial_references("NameService");
            NamingContext ncRef = NamingContextHelper.narrow(obRef);

            NameComponent nc = new NameComponent("DataNodeLancher", "");
            NameComponent[] path = { nc };

            this.dataNode = DataNodeHelper.narrow(ncRef.resolve(path));
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    @Override
    public int open(String filepath, int mode) {
        //���ݽ��յ����ļ�Ԫ������Ϣ�Ͷ�дģʽ�����ļ�������
        this.filepath = filepath;
        FileMetaData fileMetaData = nameNode.open(filepath,mode);
        if(fileMetaData.fileName.equals("")&&fileMetaData.fileType==0){
            return 0;
        }else {
            FileDesc fileDesc = new FileDesc(fdId,mode,fileMetaData,filepath);
            fileDescArrayList.add(fdId-4096,fileDesc);
            return fdId++;
        }
    }


    @Override
    public void append(int fd, byte[] bytes) {
        FileDesc fileDesc = fileDescArrayList.get(fd-4096);
        //����Ƿ���Ȩ��
        if(fileDesc==null||fileDesc.getMode() == 0){
            System.out.println("INFO: APPEND NOT ALLOWED");
            return;
        }
        fileDesc.setFileMetaData(nameNode.open(fileDesc.getFilepath(),0));
        fileMetaData = fileDesc.getFileMetaData();
        DataBlock dataBlock = fileMetaData.getLastDataBlock();
        int initLength = fileMetaData.dataMap.length;
        //���DataNode�ĵ�ַ
        String[] dnIPs = nameNode.allocateDN(fileDesc.getFilepath(),bytes.length);
        fileMetaData = nameNode.open(fileDesc.getFilepath(),0);
        if(dnIPs == null){
            System.out.println("the file doesn't exists!");
            return;
        }
        int headLength=0;
        for(int i=0; i < dnIPs.length;i++){
            String[] ports = dnIPs[i].split("/");
            connectDataNode(ports);
            System.out.println("client append for datanode start...");
            int length;

            if(bytes.length + (dataBlock==null?0:dataBlock.offsize)<Config.BLOCKSIZE){
                length = bytes.length;
            }else{
                if(i == 0){
                    length = (int) (Config.BLOCKSIZE - dataBlock.offsize);
                    headLength = length;
                }else{
                    length = Math.min(Config.BLOCKSIZE,bytes.length-Config.BLOCKSIZE*i-headLength);
                }
            }
            byte[] b1 = new byte[Config.BLOCKSIZE];

            System.arraycopy(bytes,Config.BLOCKSIZE*i,b1,0,length);
            int fileBlockId;
            if(initLength+i-1<0){
                fileBlockId = 0;
            }else {
                fileBlockId = initLength+i-1;
            }
            dataNode.append((int)fileMetaData.dataMap[fileBlockId].dtBlockId,b1);
        }
    }

    @Override
    public byte[] read(int fd) {
        FileDesc fileDesc = fileDescArrayList.get(fd-4096);
        if(fileDesc.getMode()==1){System.out.println("INFO: READ NOT ALLOWED");return null;}
        FileMetaData fileMetaData = nameNode.open(fileDesc.getFilepath(),0);
        DataBlock[] dataBlocks = fileMetaData.dataMap;
        byte[] resBytes = new byte[0];
        for (DataBlock dataBlock:dataBlocks){
            String[] ports = dataBlock.dataNodeIP.split("/");
            connectDataNode(ports);
            byte[] bytes = new byte[Config.BLOCKSIZE];
            bytes = dataNode.read((int) dataBlock.dtBlockId);
            ArrayList<Byte> bytes1 = new ArrayList<>();
            for(int i=0;i<bytes.length;i++){
                if(bytes[i]!=0x00){
                    bytes1.add(bytes[i]);
                }
            }
            byte[] tempResBytes = new byte[bytes1.size()+resBytes.length];
            for(int i=0;i<resBytes.length;i++){
                tempResBytes[i] = resBytes[i];
            }
            for(int i=0;i<bytes1.size();i++){
                tempResBytes[i+resBytes.length]=bytes1.get(i);
            }
            resBytes = tempResBytes.clone();
        }
        return resBytes;
    }

    @Override
    public void close(int fd) {
        try {
            FileDesc fileDesc = fileDescArrayList.get(fd-4096);
            nameNode.close(fileDesc.getFilepath());
            fileDescArrayList.set(fd-4096,null);
        }catch (Exception ignored){
        }
    }

    public FileDesc getFdesc(int fd){
        try {
            return fileDescArrayList.get(fd-4096);
        }catch (Exception e){
            return null;
        }
    }

}
