package raft

//
// this is an outline of the API that raft must expose to
// the service (or tester). see comments below for
// each of these functions for more details.
//
// rf = Make(...)
//   create a new Raft server.
// rf.Start(command interface{}) (index, term, isleader)
//   start agreement on a new log entry
// rf.GetState() (term, isLeader)
//   ask a Raft for its current term, and whether it thinks it is leader
// ApplyMsg
//   each time a new entry is committed to the log, each Raft peer
//   should send an ApplyMsg to the service (or tester)
//   in the same server.
//

import (
	//	"bytes"

	"math/rand"
	"sync"
	"sync/atomic"
	"time"

	//	"6.5840/labgob"
	"6.5840/labrpc"
)

// as each Raft peer becomes aware that successive log entries are
// committed, the peer should send an ApplyMsg to the service (or
// tester) on the same server, via the applyCh passed to Make(). set
// CommandValid to true to indicate that the ApplyMsg contains a newly
// committed log entry.
//
// in part 2D you'll want to send other kinds of messages (e.g.,
// snapshots) on the applyCh, but set CommandValid to false for these
// other uses.
type ApplyMsg struct {
	CommandValid bool
	Command      interface{}
	CommandIndex int

	// For 2D:
	SnapshotValid bool
	Snapshot      []byte
	SnapshotTerm  int
	SnapshotIndex int
}

const (
	Leader    int = 0
	Candidate int = 1
	Follower  int = 2
)

var HeartBeatTimeOut = 10 * time.Millisecond

// A Go object implementing a single Raft peer.
type Raft struct {
	mu        sync.Mutex          // Lock to protect shared access to this peer's state
	peers     []*labrpc.ClientEnd // RPC end points of all peers
	persister *Persister          // Object to hold this peer's persisted state
	me        int                 // this peer's index into peers[]
	dead      int32               // set by Kill()

	// Your data here (2A, 2B, 2C).
	// Look at the paper's Figure 2 for a description of what
	// state a Raft server must maintain.
	currentTerm int //当前term
	voteFor     int //投票对象
	log         []LogEntry

	commitIndex int
	lastApplied int

	nextIndex  []int
	matchIndex []int

	myStatus    int           //当前raft状态
	voteTimeout time.Duration //变成candidate的超时时间，不同raft不同
	timer       *time.Ticker
	applyChan   chan ApplyMsg
}

type LogEntry struct {
	Term    int
	Command interface{}
}

// return currentTerm and whether this server
// believes it is the leader.
func (rf *Raft) GetState() (int, bool) {

	var term int
	var isleader bool
	// Your code here (2A).
	rf.mu.Lock()
	term = rf.currentTerm
	if rf.myStatus == Leader {
		isleader = true
	} else {
		isleader = false
	}
	rf.mu.Unlock()
	return term, isleader
}

// save Raft's persistent state to stable storage,
// where it can later be retrieved after a crash and restart.
// see paper's Figure 2 for a description of what should be persistent.
// before you've implemented snapshots, you should pass nil as the
// second argument to persister.Save().
// after you've implemented snapshots, pass the current snapshot
// (or nil if there's not yet a snapshot).
func (rf *Raft) persist() {
	// Your code here (2C).
	// Example:
	// w := new(bytes.Buffer)
	// e := labgob.NewEncoder(w)
	// e.Encode(rf.xxx)
	// e.Encode(rf.yyy)
	// raftstate := w.Bytes()
	// rf.persister.Save(raftstate, nil)
}

// restore previously persisted state.
func (rf *Raft) readPersist(data []byte) {
	if data == nil || len(data) < 1 { // bootstrap without any state?
		return
	}
	// Your code here (2C).
	// Example:
	// r := bytes.NewBuffer(data)
	// d := labgob.NewDecoder(r)
	// var xxx
	// var yyy
	// if d.Decode(&xxx) != nil ||
	//    d.Decode(&yyy) != nil {
	//   error...
	// } else {
	//   rf.xxx = xxx
	//   rf.yyy = yyy
	// }
}

// the service says it has created a snapshot that has
// all info up to and including index. this means the
// service no longer needs the log through (and including)
// that index. Raft should now trim its log as much as possible.
func (rf *Raft) Snapshot(index int, snapshot []byte) {
	// Your code here (2D).

}

// example RequestVote RPC arguments structure.
// field names must start with capital letters!
type VoteErr int64

const (
	Nil              VoteErr = iota //投票过程无误
	VoteReqOutofDate                //投票消息过期
	VotedThisTerm                   //本Term内已经投过票
	RaftKilled                      //Raft程已终止
)

type RequestVoteArgs struct {
	// Your data here (2A, 2B).
	Term         int //candidate's term
	CandidateId  int //candidate requesting vote
	LastLogIndex int
	LastLogTerm  int
}

// example RequestVote RPC reply structure.
// field names must start with capital letters!
type RequestVoteReply struct {
	// Your data here (2A).
	Term        int  //currentTerm, for candidate to update itself
	VoteGranted bool //true means candidate received vote
}

// 心跳结构体
type AppendEntryArgs struct {
	Term         int //leader's term
	LeaderId     int
	PreLogIndex  int
	PreLogTerm   int
	LeaderCommit int
}

type AppendEntryReply struct {
	Term    int //current term, for leader to update itself
	Success bool
}

// 无论是投票请求还是心跳，都应当保证返回的term是最新的，要么是请求包中的值，要么是节点上的值
// example RequestVote RPC handler.
func (rf *Raft) RequestVote(args *RequestVoteArgs, reply *RequestVoteReply) {
	// Your code here (2A, 2B).
	if rf.killed() {
		reply.Term = -1
		reply.VoteGranted = false
		return
	}
	rf.mu.Lock()
	//请求term更小，不投票
	if args.Term < rf.currentTerm {
		reply.Term = rf.currentTerm
		reply.VoteGranted = false
		rf.mu.Unlock()
		return
	}
	//请求term大于当前term,变为follower，投出票
	if args.Term > rf.currentTerm {
		rf.myStatus = Follower
		rf.currentTerm = args.Term
		rf.voteFor = args.CandidateId
		reply.Term = args.Term
		reply.VoteGranted = true
		rf.timer.Reset(rf.voteTimeout)
		rf.mu.Unlock()
		return
	}

	if args.Term == rf.currentTerm {
		reply.Term = args.Term
		//已经投过票，并且投给了同一个candidate，则不再投票
		if rf.voteFor == args.CandidateId {
			rf.myStatus = Follower
			reply.VoteGranted = false
			rf.timer.Reset(rf.voteTimeout)
			rf.mu.Unlock()
			return
		}
		//投票给其他的candidate，则不再投票
		if rf.voteFor != -1 {
			reply.VoteGranted = false
			rf.mu.Unlock()
			return
		}
		//还没有投票，直接投票
		rf.voteFor = args.CandidateId
		rf.myStatus = Follower
		rf.timer.Reset(rf.voteTimeout)
		reply.VoteGranted = true
	}
	//fmt.Println(rf.me, " 开始投票，", "当前term ", rf.currentTerm, "接收到：", args.Term, " 投票给 ", args.CandidateId)

	rf.mu.Unlock()
	return

}

func (rf *Raft) AppendEntry(args *AppendEntryArgs, reply *AppendEntryReply) {
	if rf.killed() {
		reply.Term = -1
		reply.Success = false
		return
	}
	rf.mu.Lock()
	//之前的心跳，无效，返回最新轮期
	if args.Term < rf.currentTerm {
		reply.Term = rf.currentTerm
		reply.Success = false
		rf.mu.Unlock()
		return
	}

	//最新的心跳
	rf.currentTerm = args.Term
	rf.voteFor = -1
	rf.myStatus = Follower
	rf.timer.Reset(rf.voteTimeout)

	reply.Term = rf.currentTerm
	reply.Success = true
	rf.mu.Unlock()
	return
}

// example code to send a RequestVote RPC to a server.
// server is the index of the target server in rf.peers[].
// expects RPC arguments in args.
// fills in *reply with RPC reply, so caller should
// pass &reply.
// the types of the args and reply passed to Call() must be
// the same as the types of the arguments declared in the
// handler function (including whether they are pointers).
//
// The labrpc package simulates a lossy network, in which servers
// may be unreachable, and in which requests and replies may be lost.
// Call() sends a request and waits for a reply. If a reply arrives
// within a timeout interval, Call() returns true; otherwise
// Call() returns false. Thus Call() may not return for a while.
// A false return can be caused by a dead server, a live server that
// can't be reached, a lost request, or a lost reply.
//
// Call() is guaranteed to return (perhaps after a delay) *except* if the
// handler function on the server side does not return.  Thus there
// is no need to implement your own timeouts around Call().
//
// look at the comments in ../labrpc/labrpc.go for more details.
//
// if you're having trouble getting RPC to work, check that you've
// capitalized all field names in structs passed over RPC, and
// that the caller passes the address of the reply struct with &, not
// the struct itself.
func (rf *Raft) sendRequestVote(server int, args *RequestVoteArgs, reply *RequestVoteReply, voteNum *int) bool {
	if rf.killed() {
		return false
	}
	ok := rf.peers[server].Call("Raft.RequestVote", args, reply)
	//失败重传
	for !ok {
		if rf.killed() {
			return false
		}
		ok := rf.peers[server].Call("Raft.RequestVote", args, reply)
		if ok {
			break
		}
	}

	if rf.killed() {
		return false
	}
	rf.mu.Lock()
	//fmt.Println("候选人", rf.me, "发起投票")
	if args.Term < rf.currentTerm { //返回的是过期请求，不处理
		rf.mu.Unlock()
		return false
	}

	//当前轮期已不是最新，可能已选出leader，更新rf
	if reply.Term > rf.currentTerm {
		rf.currentTerm = reply.Term
		rf.voteFor = -1
		rf.myStatus = Follower
		rf.voteTimeout = time.Duration(rand.Intn(150)+200) * time.Millisecond
		rf.timer.Reset(rf.voteTimeout)
		rf.mu.Unlock()
		return ok
	}

	//在同一轮期内，若投票有效则votenum++
	if reply.Term == rf.currentTerm && reply.VoteGranted {
		if *voteNum <= len(rf.peers)/2 {
			*voteNum++
		}
		//fmt.Println("当前 ", rf.me, "term为", reply.Term, " 接收到term", reply.Term)
		if *voteNum > len(rf.peers)/2 {
			*voteNum = 0
			//已经是leader，不重置定时时间
			if rf.myStatus == Leader {
				rf.mu.Unlock()
				return ok
			}
			//变为leader，设置定时心跳时间
			rf.myStatus = Leader
			rf.timer.Reset(HeartBeatTimeOut)
			//fmt.Println("leader ", rf.me)
		}
	}
	//fmt.Println("释放锁")
	rf.mu.Unlock()
	//rf.mu.Unlock()
	return ok
}

func (rf *Raft) sendAppendEntry(server int, args *AppendEntryArgs, reply *AppendEntryReply) bool {
	if rf.killed() {
		return false
	}
	ok := rf.peers[server].Call("Raft.AppendEntry", args, reply)
	//失败重传
	for !ok {
		if rf.killed() {
			return false
		}
		ok := rf.peers[server].Call("Raft.AppendEntry", args, reply)
		if ok {
			break
		}
	}
	if rf.killed() {
		return false
	}
	rf.mu.Lock()
	//超时心跳
	if reply.Term > rf.currentTerm {
		rf.myStatus = Follower
		rf.currentTerm = reply.Term
		rf.voteFor = -1
		rf.timer.Reset(rf.voteTimeout)
	}
	rf.mu.Unlock()
	return false
}

// the service using Raft (e.g. a k/v server) wants to start
// agreement on the next command to be appended to Raft's log. if this
// server isn't the leader, returns false. otherwise start the
// agreement and return immediately. there is no guarantee that this
// command will ever be committed to the Raft log, since the leader
// may fail or lose an election. even if the Raft instance has been killed,
// this function should return gracefully.
//
// the first return value is the index that the command will appear at
// if it's ever committed. the second return value is the current
// term. the third return value is true if this server believes it is
// the leader.
func (rf *Raft) Start(command interface{}) (int, int, bool) {
	index := -1
	term := -1
	isLeader := true

	// Your code here (2B).

	return index, term, isLeader
}

// the tester doesn't halt goroutines created by Raft after each test,
// but it does call the Kill() method. your code can use killed() to
// check whether Kill() has been called. the use of atomic avoids the
// need for a lock.
//
// the issue is that long-running goroutines use memory and may chew
// up CPU time, perhaps causing later tests to fail and generating
// confusing debug output. any goroutine with a long-running loop
// should call killed() to check whether it should stop.
func (rf *Raft) Kill() {
	atomic.StoreInt32(&rf.dead, 1)
	// Your code here, if desired.
}

func (rf *Raft) killed() bool {
	z := atomic.LoadInt32(&rf.dead)
	return z == 1
}

func (rf *Raft) ticker() {
	for rf.killed() == false {

		// Your code here (2A)
		// Check if a leader election should be started.

		// pause for a random amount of time between 50 and 350
		// milliseconds.
		select {
		case <-rf.timer.C:
			if rf.killed() {
				return
			}
			rf.mu.Lock()
			//fmt.Println(rf.me, "  状态是：", rf.myStatus, "   term是：", rf.currentTerm)
			currStatus := rf.myStatus
			switch currStatus {
			case Follower:
				rf.myStatus = Candidate
				fallthrough
			case Candidate:
				//给自己投票
				rf.currentTerm += 1
				rf.voteFor = rf.me
				//每次选举开始时，重新设置选举超时
				rf.voteTimeout = time.Duration(rand.Intn(150)+200) * time.Millisecond
				rf.timer.Reset(rf.voteTimeout)

				voteNum := 1
				//请求投票
				for i, _ := range rf.peers {
					if i == rf.me {
						continue
					}
					voteArgs := &RequestVoteArgs{
						Term:        rf.currentTerm,
						CandidateId: rf.me,
					}
					voteReply := new(RequestVoteReply)
					//fmt.Println("发起选举", rf.me, rf.currentTerm)
					//rf.mu.Unlock()
					go rf.sendRequestVote(i, voteArgs, voteReply, &voteNum)
				}
			case Leader:
				//进行心跳
				rf.timer.Reset(HeartBeatTimeOut)
				for i, _ := range rf.peers {
					if i == rf.me {
						continue
					}
					//广播发送心跳
					appendEntryArgs := &AppendEntryArgs{
						Term:         rf.currentTerm,
						LeaderId:     rf.me,
						PreLogIndex:  0,
						PreLogTerm:   0,
						LeaderCommit: rf.commitIndex,
					}
					appendEntryReply := new(AppendEntryReply)
					//fmt.Println("leader ", rf.me, " 发出心跳")
					go rf.sendAppendEntry(i, appendEntryArgs, appendEntryReply)
				}

			}
			rf.mu.Unlock()
		}
	}
}

// the service or tester wants to create a Raft server. the ports
// of all the Raft servers (including this one) are in peers[]. this
// server's port is peers[me]. all the servers' peers[] arrays
// have the same order. persister is a place for this server to
// save its persistent state, and also initially holds the most
// recent saved state, if any. applyCh is a channel on which the
// tester or service expects Raft to send ApplyMsg messages.
// Make() must return quickly, so it should start goroutines
// for any long-running work.
func Make(peers []*labrpc.ClientEnd, me int,
	persister *Persister, applyCh chan ApplyMsg) *Raft {
	rf := &Raft{}
	rf.peers = peers
	rf.persister = persister
	rf.me = me

	// Your initialization code here (2A, 2B, 2C).
	rf.currentTerm = 0
	rf.myStatus = Follower
	// initialize from state persisted before a crash
	rf.readPersist(persister.ReadRaftState())
	rf.voteFor = -1
	rand.Seed(time.Now().UnixNano())
	rf.voteTimeout = time.Duration(rand.Intn(150)+200) * time.Millisecond
	rf.timer = time.NewTicker(rf.voteTimeout)
	// start ticker goroutine to start elections
	go rf.ticker()
	return rf
}
